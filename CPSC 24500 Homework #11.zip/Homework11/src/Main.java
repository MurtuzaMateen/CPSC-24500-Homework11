import java.time.LocalDate;
import java.util.Scanner;

/**
* Name: Murtuza Mateen
* This program creates a menu driven program and you can create a contact, remove a contact, update a
Contact, view a contact, view all contacts, and then exit the program.
*

public class Main {
    private static ContactManger manager;

    public static void main(String[] args) {
        System.out.println("Coded by Murtuza Mateen");
        manager = new ContactManger();
        showMenu();


    }

    private static void showMenu() {
        System.out.println("Please choose");
        System.out.println("1: Add a contact");
        System.out.println("2: Remove a contact");
        System.out.println("3: Update a contact");
        System.out.println("4: View a contact");
        System.out.println("5: View all contacts");
        System.out.println("6: Exit");
        System.out.print("Choice: ");
        int choice = new Scanner(System.in).nextInt();
        switch (choice) {
            case 1:
                addAContactMenu();
                showMenu();
                break;
            case 2:
                removeAContactMenu();
                showMenu();
                break;
            case 3:
                updateAContactMenu();
                showMenu();
                break;
            case 4:
                showAContact();
                showMenu();
                break;
            case 5:
                showAllContacts();
                showMenu();
                break;
            case 6:
                return;
            default:
                System.out.println("Invalid choice");
                showMenu();
        }
    }

    private static void addAContactMenu() {
        System.out.print("Enter contact name: ");
        String name = new Scanner(System.in).next();
        System.out.print("Enter dob YYYY-mm-dd: ");
        String dob = new Scanner(System.in).next();
        System.out.print("Enter phone number: ");
        String pNumber = new Scanner(System.in).next();
        System.out.print("Enter Email: ");
        String email = new Scanner(System.in).next();
        Contact contact = new Contact(name, pNumber, LocalDate.parse(dob), email);
        manager.addContact(contact);
    }

    private static void removeAContactMenu() {
        System.out.print("Enter a name: ");
        String name = new Scanner(System.in).next();
        boolean isRemoved = manager.deleteContact(name);
        String message = (isRemoved) ? "Contact removed" : "Contact not found";
        System.out.println(message);
    }

    private static void updateAContactMenu() {
        System.out.print("Enter a name: ");
        String name = new Scanner(System.in).next();
        Contact contact = manager.getContact(name);
        if (contact == null) {
            System.out.println("Contact not found");
            return;
        }

        System.out.print("Enter contact name (write - to not change): ");
        name = new Scanner(System.in).next();
        System.out.print("Enter dob YYYY-mm-dd (write - to not change): ");
        String dob = new Scanner(System.in).next();
        System.out.print("Enter phone number (write - to not change): ");
        String pNumber = new Scanner(System.in).next();
        System.out.print("Enter Email (write - to not change): ");
        String email = new Scanner(System.in).next();

        if (!name.equals("-"))
            contact.setName(name);
        if (!dob.equals("-"))
            contact.setDateOfBirth(LocalDate.parse(dob));
        if (!pNumber.equals("-"))
            contact.setPhoneNumber(pNumber);
        if (!email.equals("-"))
            contact.setEmail(email);

        manager.saveToFile();
        System.out.println("Contact updated");

    }

    private static void showAContact() {
        System.out.print("Enter a name: ");
        String name = new Scanner(System.in).next();
        Contact contact = manager.getContact(name);
        if (contact == null) {
            System.out.println("Contact not found");
        } else
            System.out.println(contact);

    }

    private static void showAllContacts() {
        for (Contact contact : manager.getContacts()) {
            System.out.println(contact);
        }
    }
}
