import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ContactManger {
    public static final String FILENAME = "Contacts.bin";
    private List<Contact> contacts;

    public ContactManger() {
        contacts = new ArrayList<>();

        try {
            FileInputStream fis = new FileInputStream(FILENAME);
            ObjectInputStream ois = new ObjectInputStream(fis);
            contacts = (ArrayList) ois.readObject();
            ois.close();
            fis.close();
        } catch (IOException ioe) {

        } catch (ClassNotFoundException c) {

        }
    }


    public void addContact(Contact contact) {
        contacts.add(contact);
        saveToFile();
    }


    public boolean deleteContact(String name) {
        Contact toDelete = null;
        for (Contact contact :
                contacts) {
            if (contact.getName().equals(name)) {
                toDelete = contact;
                break;
            }
        }
        if (toDelete == null)
            return false;
        contacts.remove(toDelete);
        saveToFile();
        return true;
    }

    public void saveToFile() {
        try {
            FileOutputStream fos = new FileOutputStream(FILENAME);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(contacts);
            oos.close();
            fos.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public Contact getContact(String name) {
        for (Contact contact :
                contacts) {
            if (contact.getName().equals(name))
                return contact;
        }
        return null;
    }

    public List<Contact> getContacts() {
        return contacts;
    }
}
